const initState = {
    books:[],
    filteredbooks = []
}

const bookReducer = (state = initState, action) => {};

export default bookReducer;

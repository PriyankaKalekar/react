import React from "react";
import logo from "./logo.svg";
import "./App.css";

import { Route, BrowserRouter, Switch } from "react-router-dom";
import Home from "./component/Home";
import About from "./component/AboutUs";
import Contact from "./component/Contact";
import NavBar from "./component/NavBar";
import SignIn from "./component/SignIn";
import SignUp from "./component/SignUp";
import Books from "./component/Books";
import LogOut from "./component/LogOut";
import MyCart from "./component/MyCart";

function App() {
  return (
    <div className="container">
            
      <BrowserRouter>
        <NavBar />
        <Switch>
          <Route exact path="/" component={Home} />
          <Route path="/about" component={About} />
          <Route path="/contact" component={Contact} />
          <Route path="/signin" component={SignIn} />
          <Route path="/signup" component={SignUp} />
          <Route path="/books" component={Books} />
          <Route path="/logout" component={LogOut} />
          <Route path="/mycart" component={MyCart} />
        </Switch>
      </BrowserRouter>
    </div>
  );
}

export default App;

import React from "react";

const Home = () => {
  return (
    <React.Fragment>
      <h1>Home</h1>
      <br />
      <br />
      <img src="{../books.jpg}" alt="Tulip" width="500" height="333" />
      <p>
        Lorem Ipsum is simply dummy text of the printing and typesetting
        industry. Lorem Ipsum has been the industry's standard dummy text ever
        since the 1500s, when an unknown printer took a galley of type and
        scrambled it to make a type specimen book.{" "}
      </p>
      <br />
      <br />
    </React.Fragment>
  );
};

export default Home;

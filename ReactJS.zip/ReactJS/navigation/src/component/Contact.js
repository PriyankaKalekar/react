import React from "react";

const Contact = () => {
  return (
    <React.Fragment>
      <h1>Contact Us</h1>
      <br />
      <br />
      <p>Some text</p>
      <br />
      <br />
    </React.Fragment>
  );
};

export default Contact;

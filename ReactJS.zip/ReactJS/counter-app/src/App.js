import React, { Component } from "react";
import NavBar from "./components/NavBar";
import CounterList from "./components/CounterList";

export default class App extends Component {
  state = {
    counters: [
      { id: 1, value: 0 },
      { id: 2, value: 0 },
      { id: 3, value: 0 },
      { id: 4, value: 0 },
      { id: 5, value: 0 }
    ]
  };

  handleDelete = id => {
    const counters = this.state.counters.filter(counter => {
      return counter.id !== id;
    });
    this.setState({ counters });
    console.log("Counter Deleted", id);
  };

  handleReset = () => {
    console.log("called reset");
    let counters = [...this.state.counters];
    counters = counters.map(c => {
      c.value = 0;
      return c;
    });
    console.log(counters);
    this.setState({ counters });
    console.log("Counter Reset");
  };

  handleIncrement = counter => {
    let counters = [...this.state.counters];
    let index = counters.indexOf(counter);
    counters[index] = { ...counter };
    counters[index].value++;
    this.setState({ counters });
  };

  handleDecrement = counter => {
    let counters = [...this.state.counters];
    let index = counters.indexOf(counter);
    counters[index] = { ...counter };
    if (counters[index].value > 0) counters[index].value--;
    this.setState({ counters });
  };

  render() {
    return (
      <div className="Container">
        <NavBar
        // totalCount={
        //   this.state.counters.filter(counter => counter.value > 0).length
        // }
        />
        <br />
        <br />
        <CounterList
          counters={this.state.counters}
          onDelete={this.handleDelete}
          onIncrement={this.handleIncrement}
          onDecrement={this.handleDecrement}
          onReset={this.handleReset}
        />
      </div>
    );
  }
}

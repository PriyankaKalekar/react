import React from "react";
import { Link } from "react-router-dom";

const Books = () => {
  return (
    <React.Fragment>
      <h1>All Books</h1>
      <br />
      <br />
      <p>List of all books</p>
      <br />
      <br />
      <Link to="/LogOut" className="btn btn-primary">
        View More
      </Link>
    </React.Fragment>
  );
};

export default Books;

import React from "react";
const ChildComponent = props => {
  return <div>{props.text}</div>;
};

export default ChildComponent;

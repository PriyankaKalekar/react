import React from "react";
import { connect } from "react-redux";
import Post from "./Post";
import EditPostForm from "./EditPostForm";

const AllPosts = props => {
  return (
    <React.Fragment>
      <h4>All posts</h4>
      {props.posts.map(post => {
        return (
          <div>
            {post.editing ? (
              <EditPostForm post={post} key={post.id} />
            ) : (
              <Post key={post.id} post={post} />
            )}
          </div>
        );
      })}
    </React.Fragment>
  );
};

const mapStateToProps = state => {
  return { posts: state.posts };
};

export default connect(mapStateToProps)(AllPosts);

import React from "react";
import { Link } from "react-router-dom";
import { withRouter } from "react-router-dom";
import { BrowserRouter, Switch, Route } from "react-router-dom";
const NavBar = () => {
  return (
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      {/* <a class="navbar-brand" href="#">
        Navbar
      </a> */}
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarNav"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <div>
          <ul class="navbar-nav">
            <li class="nav-item active">
              <Link to="/" class="nav-link">
                Home <span class="sr-only">(current)</span>
              </Link>
            </li>
          </ul>
        </div>
        <div style={{ margin: "40px" }}></div>
        <div style={{ float: "right" }}>
          <ul class="navbar-nav">
            <li class="nav-item">
              <Link to="/books" class="nav-link">
                Books
              </Link>
            </li>
            <li class="nav-item">
              <Link to="/about" class="nav-link">
                About Us
              </Link>
            </li>
            <li class="nav-item">
              <Link to="/contact" class="nav-link">
                Contact Us
              </Link>
            </li>

            <li class="nav-item">
              <Link to="/signin" class="nav-link">
                Sign In
              </Link>
            </li>

            <li class="nav-item">
              <Link to="/signup" class="nav-link">
                Sign Up
              </Link>
            </li>

            <li class="nav-item">
              <Link to="/logout" class="nav-link">
                Log Out
              </Link>
            </li>
            <li class="nav-item">
              <Link to="/mycart" class="nav-link">
                My Cart
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default withRouter(NavBar);

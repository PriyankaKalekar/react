import React, { Component } from "react";

const Counter = props => {
  const { counter, onDelete, onIncrement, onDecrement } = props;

  const getBadgeClasses = () => {
    let classes = "badge m-2 badge-";
    classes += counter.value === 0 ? "warning" : "primary";
    return classes;
  };

  const getFormatCount = () => {
    const value = counter.value;
    return counter.value === 0 ? "zero" : value;
  };

  return (
    <div className="row">
      <div className="col-1">
        <span className={getBadgeClasses()}>{getFormatCount()}</span>
      </div>
      <div className="col-3">
        <button
          className="btn btn-primary btn-sm"
          onClick={() => onIncrement(counter)}
        >
          +
        </button>

        <button
          className="btn btn-primary btn-sm"
          disabled={counter.value === 0 ? "disabled" : ""}
          onClick={() => onDecrement(counter)}
        >
          -
        </button>

        <button
          className="btn btn-danger btn-sm"
          onClick={() => onDelete(counter.id)}
        >
          Delete
        </button>
      </div>
    </div>
  );
};

export default Counter;

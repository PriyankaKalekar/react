import React, { Component } from "react";
import Counter from "./Counter";

export default class CounterList extends Component {
  style = {
    float: "left"
  };
  render() {
    return (
      <div className="container">
        <button
          className="btn btn-primary"
          style={{ float: "left" }}
          onClick={this.props.onReset}
        >
          Reset
        </button>
        <br />
        <br />
        {this.props.counters.map(counter => (
          <Counter
            counter={counter}
            key={counter.id}
            onDelete={this.props.onDelete}
            onIncrement={this.props.onIncrement}
            onDecrement={this.props.onDecrement}
          />
        ))}
      </div>
    );
  }
}

import React from "react";
import { Link } from "react-router-dom";

const LogOut = () => {
  return (
    <React.Fragment>
      <h1>Log Out</h1>
      <br />
      <br />
      <p>You have successfully been logged out!</p>
      <br />
      <br />
      <Link to="/SignUp" className="btn btn-primary">
        Sign Up
      </Link>
      <br /> <br />
      <Link to="/SignIn" className="btn btn-primary">
        Sign In
      </Link>
    </React.Fragment>
  );
};

export default LogOut;

const cartReducer = (state = {}, action) => {
  switch (action.type) {
    default:
      return state;
  }
};

export default cartReducer;

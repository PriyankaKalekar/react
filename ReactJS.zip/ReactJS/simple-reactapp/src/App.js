import React from "react";
import logo from "./logo.svg";
import "./App.css";
import ParentComponent from "./components/ParentComponent";
import EmployeeList from "./components/EmployeeList";

function App() {
  return <EmployeeList />;
}

export default App;

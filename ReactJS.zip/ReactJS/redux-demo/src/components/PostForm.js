import React from "react";
import { connect } from "react-redux";

const PostForm = props => {
  console.log(props);

  let titleField = React.createRef();
  let messageField = React.createRef();

  const handleAddPost = e => {
    e.preventDefault();
    console.log(titleField);
    console.log(messageField);

    let newpost = {
      id: new Date(),
      title: titleField.current.value,
      message: messageField.current.value,
      editing: false
    };

    props.dispatch({
      type: "ADD_POST",
      post: newpost
    });

    titleField.current.value = "";
    messageField.current.value = "";
  };

  return (
    <React.Fragment>
      <br />
      <h4>Add new post</h4>
      <br />
      <form style={{ width: "40%" }}>
        <div className="form-group">
          <input
            type="text"
            className="form-control"
            required
            autoFocus
            placeholder="Enter post title"
            ref={titleField}
          />
        </div>

        <div className="form-group">
          <textarea
            type="text"
            className="form-control"
            required
            autoFocus
            placeholder="Enter post message"
            ref={messageField}
          ></textarea>
        </div>

        <div className="form-group">
          <button
            type="submit"
            className="btn btn-primary"
            onClick={handleAddPost}
          >
            Add Post
          </button>
        </div>
      </form>
      <br />
      <br />
    </React.Fragment>
  );
};

export default connect()(PostForm);

import React from "react";
import { Link } from "react-router-dom";

const About = () => {
  return (
    <React.Fragment>
      <h1>About Us</h1>
      <br />
      <br />
      <p>Some text</p>
      <br />
      <br />
      <Link to="/Contact" className="btn btn-primary">
        Contact Us
      </Link>
    </React.Fragment>
  );
};

export default About;

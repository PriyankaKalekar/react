import React from "react";

const Employee = props => {
  return (
    <React.Fragment>
      <div>{props.employees.length} records found</div>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th> Id </th>
            <th> Name </th>
            <th> Salary </th>
            <th> Department </th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {props.employees.map(employee => {
            return (
              <tr key={employee.id}>
                <td>{employee.id}</td>
                <td>{employee.name}</td>
                <td>{employee.salary}</td>
                <td>{employee.department}</td>
                <td>
                  <button className="btn btn-sm btn-danger">Delete</button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </React.Fragment>
  );
};

export default Employee;

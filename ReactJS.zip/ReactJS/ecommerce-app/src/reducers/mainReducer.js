import { combineReducers } from "redux";
import customerReducer from "./customerReducer";
import cartReducer from "./cartReducer";
import bookReducer from "./bookReducer";

const mainReducer = combineReducers({
  customer: customerReducer,
  cart: cartReducer,
  book: bookReducer
});

export default mainReducer;

import React from "react";
import { connect } from "react-redux";

const EditPostForm = props => {
  console.log(props);
  const { post } = props;
  let titleField = React.createRef();
  let messageField = React.createRef();

  const handleUpdatePost = () => {
    const updatedPost = {
      id: post.id,
      title: titleField.current.value,
      message: messageField.current.value,
      editing: !post.editing
    };
    props.dispatch({
      type: "UPDATE_POST",
      post: updatedPost
    });
  };

  return (
    <React.Fragment>
      <br />
      <form style={{ width: "40%" }}>
        <div className="form-group">
          <input
            type="text"
            className="form-control"
            required
            autoFocus
            defaultValue={post.title}
            ref={titleField}
          />
        </div>

        <div className="form-group">
          <textarea
            type="text"
            className="form-control"
            required
            autoFocus
            defaultValue={post.message}
            ref={messageField}
          ></textarea>
        </div>

        <div className="form-group">
          <button
            type="submit"
            className="btn btn-primary"
            onClick={handleUpdatePost}
          >
            Update Post
          </button>
        </div>
      </form>
      <br />
      <br />
    </React.Fragment>
  );
};

export default connect()(EditPostForm);

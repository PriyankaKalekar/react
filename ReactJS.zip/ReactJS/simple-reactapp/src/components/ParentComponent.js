import React, { Component } from "react";
import ChildComponent from "./ChildComponent";

export default class ParentComponent extends Component {
  render() {
    return (
      <div>
        I am a parent component!
        <ChildComponent text="I am first child component" />
        <ChildComponent text="I am second child component" />
        <ChildComponent text="I am third child component" />
      </div>
    );
  }
}

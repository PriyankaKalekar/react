import React, { Component } from "react";
import Employee from "./Employee";

export default class EmployeeList extends Component {
  state = {
    employees: [
      { id: 101, name: "Mario Speedwagon", salary: 90000, department: "IT" },
      { id: 102, name: "Petey Cruiser", salary: 80000, department: "Sales" },
      { id: 103, name: "Anna Sthesia", salary: 70000, department: "HR" },
      { id: 104, name: "Paul Molive", salary: 60000, department: "Operations" },
      { id: 105, name: "Gail Forcewind", salary: 50000, department: "IT" }
    ]
  };

  render() {
    return (
      <div className="container">
        <Employee employees={this.state.employees} />
      </div>
    );
  }
}

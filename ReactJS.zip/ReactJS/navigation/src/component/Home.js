import React from "react";

const Home = () => {
  return (
    <React.Fragment>
      <h1>Home Component</h1>
      <br />
      <br />
      <p>Some text</p>
      <br />
      <br />
    </React.Fragment>
  );
};

export default Home;

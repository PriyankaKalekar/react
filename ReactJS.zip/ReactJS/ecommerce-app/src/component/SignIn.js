import React from "react";
import { Link } from "react-router-dom";

const SignIn = () => {
  return (
    <React.Fragment>
      <h1>Sign In</h1>
      <br />
      <br />
      <p>Enter your details to sign in!</p>
      <br />
      <br />
      <Link to="/LogOut" className="btn btn-primary">
        Log Out
      </Link>
    </React.Fragment>
  );
};

export default SignIn;

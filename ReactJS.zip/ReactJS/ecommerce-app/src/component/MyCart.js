import React from "react";
import { Link } from "react-router-dom";

const MyCart = () => {
  return (
    <React.Fragment>
      <h1>Items in cart....</h1>
      <br />
      <br />
      <p>List of all items</p>
      <br />
      <br />
      <Link to="/Home" className="btn btn-primary">
        Go to Home Page
      </Link>
    </React.Fragment>
  );
};

export default MyCart;
